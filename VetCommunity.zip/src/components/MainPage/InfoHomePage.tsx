import "./InfoHome.css";

const InfoHomePage = () => {
  return (
    <div className="InfoHome">
      Your Veterany Information and needs all in one Place
    </div>
  );
};

export default InfoHomePage;

// A semi slogal / text to identify the usage of this site.
